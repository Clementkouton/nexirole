# =====================================================================
# NEXIROLE - MICRO-FIX-AUTOSAVE
# Branche une sauvegarde automatique en base ~1,2 s apres chaque
# amelioration IA du CV Builder (createur/page.tsx).
#
# Securite :
#   - copie de secours automatique (.bak-MICROFIX-<horodatage>)
#   - si l'analyse du fichier n'est pas claire a 100%, AUCUNE ecriture
#     n'est effectuee (mode diagnostic) : le script affiche les extraits
#     a renvoyer a l'assistant.
#
# Usage (depuis la racine du projet, a cote de package.json) :
#   powershell -ExecutionPolicy Bypass -File .\micro-fix-sauvegarde-ia.ps1
#
# Annuler : remets le fichier .bak-MICROFIX-... a la place de page.tsx
# =====================================================================

param([string]$Fichier = "")

$ErrorActionPreference = "Stop"

function Find-ClosingBrace([string]$s, [int]$openIdx) {
    $depth = 0
    for ($i = $openIdx; $i -lt $s.Length; $i++) {
        $ch = $s[$i]
        if ($ch -eq '{') { $depth++ }
        elseif ($ch -eq '}') { $depth--; if ($depth -eq 0) { return $i } }
    }
    return -1
}

function Num-Ligne([string]$txt, [int]$index) {
    if ($index -le 0) { return 1 }
    return ([regex]::Matches($txt.Substring(0, $index), "`n")).Count + 1
}

function Show-Diagnostic([string]$txt, [object[]]$saveC, [object[]]$aiC, [string]$raison) {
    Write-Host ""
    Write-Host "====================================================="
    Write-Host " MODE DIAGNOSTIC : AUCUNE ECRITURE EFFECTUEE"
    Write-Host "====================================================="
    Write-Host (" Raison : " + $raison)
    Write-Host ""
    Write-Host "[Fonctions de sauvegarde detectees]"
    if ($saveC.Count -eq 0) {
        Write-Host "  (aucune)"
    } else {
        foreach ($c in $saveC) {
            Write-Host ("  ligne {0} : {1}" -f $c.Line, $c.Name)
        }
    }
    Write-Host ""
    Write-Host "[Gestionnaires d'amelioration IA detectes]"
    if ($aiC.Count -eq 0) {
        Write-Host "  (aucun)"
    } else {
        foreach ($c in $aiC) {
            Write-Host ("  ligne {0} : {1}" -f $c.Line, $c.Name)
        }
    }
    Write-Host ""
    Write-Host "[Extraits autour des mots-cles IA - copie ce bloc et renvoie-le a l'assistant]"
    $lignes = $txt -split "`r?`n"
    $hits = @()
    for ($i = 0; $i -lt $lignes.Count; $i++) {
        if ($lignes[$i] -match '(?i)amelior|am\u00e9lior|improv|enhanc|optimis|with.?ai|avec.?ia') { $hits += $i }
    }
    if ($hits.Count -eq 0) {
        Write-Host "  (aucune ligne avec les mots-cles IA trouvee)"
    } else {
        $affiches = @{}
        $n = 0
        foreach ($h in $hits) {
            if ($n -ge 12) {
                Write-Host "  ... (autres occurrences omises)"
                break
            }
            for ($j = [Math]::Max(0, $h - 2); $j -le [Math]::Min($lignes.Count - 1, $h + 2); $j++) {
                if (-not $affiches.ContainsKey($j)) {
                    $affiches[$j] = $true
                    Write-Host ("  {0,5} | {1}" -f ($j + 1), $lignes[$j])
                }
            }
            Write-Host "  ----"
            $n++
        }
    }
    Write-Host ""
    Write-Host "Le fichier n'a PAS ete modifie. Copie le bloc ci-dessus dans la conversation."
}

# ---------------------------------------------------------------------
# 1. Localiser le fichier
# ---------------------------------------------------------------------
if ($Fichier -ne "") {
    $Chemin = $Fichier
} else {
    $Chemin = Join-Path (Get-Location) "src\app\dashboard\cv-builder\createur\page.tsx"
}

if (-not (Test-Path $Chemin)) {
    Write-Host "[!] Fichier introuvable : $Chemin"
    Write-Host "    Lance ce script depuis la racine du projet (le dossier qui contient package.json),"
    Write-Host "    ou passe le chemin : -Fichier ""chemin\vers\page.tsx"""
    exit 1
}

Write-Host ("[1/6] Fichier cible : " + $Chemin)

# ---------------------------------------------------------------------
# 2. Lecture (UTF-8, BOM preserve) + fin de ligne detectee
# ---------------------------------------------------------------------
$bytes = [System.IO.File]::ReadAllBytes($Chemin)
$aBom = ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF)
$enc = New-Object System.Text.UTF8Encoding($aBom)
$txt = $enc.GetString($bytes)
if ($txt.Length -gt 0 -and $txt[0] -eq [char]0xFEFF) { $txt = $txt.Substring(1) }

$crlfCount = ([regex]::Matches($txt, "`r`n")).Count
$lfCount = ([regex]::Matches($txt, "`n")).Count
$nl = if ($crlfCount -ge ($lfCount - $crlfCount)) { "`r`n" } else { "`n" }

if ($txt.Contains("MICRO-FIX-AUTOSAVE")) {
    Write-Host "[i] Le micro-fix est deja applique dans ce fichier. Rien a faire."
    exit 0
}

# ---------------------------------------------------------------------
# 3. Copie de secours (seulement si une modification est envisagee)
# ---------------------------------------------------------------------
$horodatage = Get-Date -Format "yyyyMMdd-HHmmss"
$backupPath = "$Chemin.bak-MICROFIX-$horodatage"
Copy-Item -LiteralPath $Chemin -Destination $backupPath
Write-Host ("[2/6] Copie de secours : " + $backupPath)

# ---------------------------------------------------------------------
# 4. Detection : fonction de sauvegarde existante
# ---------------------------------------------------------------------
Write-Host "[3/6] Recherche de la fonction de sauvegarde existante..."

$reFn = '(?m)\b(?:const|function)\s+([A-Za-z_$][A-Za-z0-9_$]*)\s*[=(]'
$saveCandidates = @()
foreach ($m in [regex]::Matches($txt, $reFn)) {
    $name = $m.Groups[1].Value
    if ($name -match '^(is|has|on|set|get)') { continue }
    if ($name -match '(?i)(save|persist|sauveg)') {
        $saveCandidates += [pscustomobject]@{
            Name  = $name
            Index = $m.Index
            Line  = Num-Ligne $txt $m.Index
        }
    }
}

$saveFn = $null
if ($saveCandidates.Count -eq 1) {
    $saveFn = $saveCandidates[0]
} elseif ($saveCandidates.Count -gt 1) {
    $avecCv = @($saveCandidates | Where-Object { $_.Name -match '(?i)cv' })
    if ($avecCv.Count -eq 1) { $saveFn = $avecCv[0] }
}

# ---------------------------------------------------------------------
# 5. Detection : gestionnaire d'amelioration IA
# ---------------------------------------------------------------------
Write-Host "[4/6] Recherche du gestionnaire d'amelioration IA..."

$reNomIa = '([iI]mprov|[aA]melior|[aA]m\u00e9lior|[eE]nhanc|[oO]ptimis|[rR]efin|[wW]ithAI|[wW]ithAi|[aA]vecIA|[aA]vecIa|[gG]enererIA|[gG]enererAvecIa)'
$reMotsClesIa = '(?i)amelior|am\u00e9lior|improv|enhanc|optimis|refin'

$aiCandidates = @()
foreach ($m in [regex]::Matches($txt, $reFn)) {
    $name = $m.Groups[1].Value
    if ($name -notmatch $reNomIa) { continue }
    $openIdx = $txt.IndexOf("{", $m.Index + $m.Length)
    if ($openIdx -lt 0 -or ($openIdx - $m.Index) -gt 500) { continue }
    $closeIdx = Find-ClosingBrace $txt $openIdx
    if ($closeIdx -lt 0) { continue }
    $body = $txt.Substring($openIdx, $closeIdx - $openIdx)
    if ($body.Length -gt 30000) { continue }
    if (($body -match $reMotsClesIa) -or ($body -match '\bset[A-Z]')) {
        $aiCandidates += [pscustomobject]@{
            Name     = $name
            Index    = $m.Index
            Line     = Num-Ligne $txt $m.Index
            OpenIdx  = $openIdx
            CloseIdx = $closeIdx
        }
    }
}

# Passe 2 (secours) : scanner le corps de toutes les fonctions
if ($aiCandidates.Count -eq 0) {
    foreach ($m in [regex]::Matches($txt, $reFn)) {
        $name = $m.Groups[1].Value
        if ($name -match '(?i)(save|persist|sauveg)') { continue }
        $openIdx = $txt.IndexOf("{", $m.Index + $m.Length)
        if ($openIdx -lt 0 -or ($openIdx - $m.Index) -gt 500) { continue }
        $closeIdx = Find-ClosingBrace $txt $openIdx
        if ($closeIdx -lt 0) { continue }
        $body = $txt.Substring($openIdx, $closeIdx - $openIdx)
        if ($body.Length -gt 30000) { continue }
        if (($body -match $reMotsClesIa) -and ($body -match '\bset[A-Z]')) {
            $aiCandidates += [pscustomobject]@{
                Name     = $name
                Index    = $m.Index
                Line     = Num-Ligne $txt $m.Index
                OpenIdx  = $openIdx
                CloseIdx = $closeIdx
            }
        }
    }
}

# ---------------------------------------------------------------------
# 6. Verification : composant principal + import useEffect
# ---------------------------------------------------------------------
$reComp = '(?m)export\s+default\s+function\s+[A-Za-z_$][A-Za-z0-9_$]*\s*\([^)]*\)\s*\{'
$compMatch = [regex]::Match($txt, $reComp)

$aDesEffets = $txt -match '\buseEffect\b'

# ---------------------------------------------------------------------
# Controle final : tout est clair OU mode diagnostic (aucune ecriture)
# ---------------------------------------------------------------------
$raison = ""
if (-not $saveFn) { $raison = "fonction de sauvegarde introuvable ou ambigue" }
elseif ($aiCandidates.Count -eq 0) { $raison = "aucun gestionnaire d'amelioration IA detecte" }
elseif ($aiCandidates.Count -gt 1) { $raison = "plusieurs gestionnaires IA possibles - choix impossible sans risque" }
elseif (-not $compMatch.Success) { $raison = "composant principal (export default function) introuvable" }

if ($raison -ne "") {
    Show-Diagnostic $txt $saveCandidates $aiCandidates $raison
    exit 0
}

$ai = $aiCandidates[0]

if ($ai.CloseIdx -le $compMatch.Index + $compMatch.Length) {
    Show-Diagnostic $txt $saveCandidates $aiCandidates "position incoherente entre le composant et le gestionnaire IA"
    exit 0
}

if (-not $aDesEffets) {
    Write-Host "[!] useEffect n'est pas importe dans ce fichier : il sera ajoute a l'import React."
}

Write-Host ("[5/6] Analyse claire :")
Write-Host ("      - fonction de sauvegarde      : " + $saveFn.Name + " (ligne " + $saveFn.Line + ")")
Write-Host ("      - gestionnaire IA             : " + $ai.Name + " (ligne " + $ai.Line + ")")

# ---------------------------------------------------------------------
# Ecriture : 3 insertions marquees MICRO-FIX-AUTOSAVE (de bas en haut)
# ---------------------------------------------------------------------
Write-Host "[6/6] Ecriture des 3 insertions..."

# (a) fin du gestionnaire IA : poser le drapeau de sauvegarde
$snippetHandler = $nl + $nl +
    "  // MICRO-FIX-AUTOSAVE : demande de sauvegarde immediate apres une amelioration IA" + $nl +
    "  (window as unknown as { __nrIaDirty?: boolean }).__nrIaDirty = true;"
$txt = $txt.Substring(0, $ai.CloseIdx) + $snippetHandler + $txt.Substring($ai.CloseIdx)

# (b) composant principal : surveille le drapeau et sauvegarde avec l'etat FRAIS
$reComp2 = '(?m)export\s+default\s+function\s+[A-Za-z_$][A-Za-z0-9_$]*\s*\([^)]*\)\s*\{'
$comp2 = [regex]::Match($txt, $reComp2)
if (-not $comp2.Success) {
    Write-Host "[!] Erreur interne : composant introuvable apres insertion (a). Restauration..."
    Copy-Item -LiteralPath $backupPath -Destination $Chemin -Force
    Write-Host "    Fichier restaure depuis la copie de secours. Aucun degat."
    exit 1
}

$snippetComp = $nl +
    "  // MICRO-FIX-AUTOSAVE (debut) : sauvegarde en base ~1,2 s apres chaque amelioration IA" + $nl +
    "  useEffect(() => {" + $nl +
    "    const t = window.setInterval(() => {" + $nl +
    "      const w = window as unknown as { __nrIaDirty?: boolean };" + $nl +
    "      if (w.__nrIaDirty) {" + $nl +
    "        w.__nrIaDirty = false;" + $nl +
    "        try { " + $saveFn.Name + "(); } catch (e) { console.error('[MICRO-FIX] sauvegarde IA :', e); }" + $nl +
    "      }" + $nl +
    "    }, 1200);" + $nl +
    "    return () => window.clearInterval(t);" + $nl +
    "  });" + $nl +
    "  // MICRO-FIX-AUTOSAVE (fin)"
$txt = $txt.Substring(0, $comp2.Index + $comp2.Length) + $snippetComp + $txt.Substring($comp2.Index + $comp2.Length)

# (c) import de useEffect si absent
if (-not $aDesEffets) {
    $reImport = '(?m)import\s*\{([^}]*)\}\s*from\s*["'']react["'']'
    $mImport = [regex]::Match($txt, $reImport)
    if ($mImport.Success) {
        $g1 = $mImport.Groups[1]
        $txt = $txt.Substring(0, $g1.Index) + "useEffect, " + $txt.Substring($g1.Index)
    } else {
        Write-Host "[!] Import React introuvable pour ajouter useEffect - verifie manuellement apres le test."
    }
}

# ---------------------------------------------------------------------
# Sauvegarde atomique + controle
# ---------------------------------------------------------------------
[System.IO.File]::WriteAllText($Chemin, $txt, (New-Object System.Text.UTF8Encoding($aBom)))

$marques = ([regex]::Matches((Get-Content -LiteralPath $Chemin -Raw), "MICRO-FIX-AUTOSAVE")).Count

Write-Host ""
Write-Host "[OK] Micro-fix applique avec succes ($marques marques trouvees)."
Write-Host ("     - fonction de sauvegarde utilisee : " + $saveFn.Name)
Write-Host ("     - gestionnaire IA modifie         : " + $ai.Name)
Write-Host "     - surveilleur ajoute au composant principal"
Write-Host ""
Write-Host "[>] Teste maintenant :"
Write-Host "     1. npm run build   (ou recharge simplement la page en dev)"
Write-Host "     2. fais une amelioration IA, attends 2 secondes"
Write-Host "     3. clique sur un bouton PDF : le contenu doit desormais correspondre"
Write-Host ""
Write-Host ("Secours : " + $backupPath)
Write-Host "Si la console du navigateur affiche '[MICRO-FIX] sauvegarde IA', copie cette erreur"
Write-Host "et les lignes autour : la fonction de sauvegarde attend peut-etre un argument."
