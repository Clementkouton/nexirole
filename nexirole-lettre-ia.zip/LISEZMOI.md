# NexiRole — Lettre IA (lettres de motivation par IA)

Nouvelle fonctionnalite complete pour NexiRole : generation de lettres de motivation avec l'IA, edition avec **sauvegarde automatique en base**, export PDF et copie. Aucune nouvelle variable d'environnement, aucune nouvelle dependance npm.

---

## 1. Contenu du zip

| Fichier du zip | Ou le copier dans ton projet |
|---|---|
| `src/lib/ai-client.ts` | `src/lib/ai-client.ts` |
| `src/lib/nr-auth.ts` | `src/lib/nr-auth.ts` |
| `src/app/api/lettre/route.ts` | `src/app/api/lettre/route.ts` |
| `src/app/api/lettre/[id]/route.ts` | `src/app/api/lettre/[id]/route.ts` |
| `src/app/api/lettre/ia-status/route.ts` | `src/app/api/lettre/ia-status/route.ts` |
| `src/app/dashboard/lettres/page.tsx` | `src/app/dashboard/lettres/page.tsx` |
| `prisma/AJOUTER-AU-SCHEMA.txt` | a coller a la fin de `prisma/schema.prisma` |
| `micro-fix-sauvegarde-ia.ps1` | a la racine du projet (a cote de `package.json`) |

## 2. Installation (7 etapes, ~10 minutes)

### Etape 1 — Copier les fichiers (1 min)

Extrais le zip. Depuis le dossier extrait, lance dans PowerShell (en remplacant `D:\Next Js\nexirole` si besoin) :

```powershell
Copy-Item -Recurse -Force .\src\* "D:\Next Js\nexirole\src\"
```

Cela fusionne les dossiers automatiquement (rien d'existant n'est ecrase, tous les fichiers sont nouveaux).

### Etape 2 — Base de donnees : modele CoverLetter (2 min)

1. Ouvre `prisma/schema.prisma`.
2. Copie tout le contenu de `prisma/AJOUTER-AU-SCHEMA.txt` (le bloc `model CoverLetter { ... }`) **a la fin** du fichier.
3. Dans le terminal, a la racine du projet :

```powershell
npx prisma db push
npx prisma generate
```

### Etape 3 — Authentification : verifier puis adapter si besoin (2 min)

Les routes API recupere l'utilisateur connecte via `src/lib/nr-auth.ts`. Par defaut il utilise **NextAuth v4** (`getServerSession` + `authOptions` depuis `@/lib/auth`).

1. Verifie ce que ton projet utilise :

```powershell
Get-ChildItem src\app\api -Recurse -Filter *.ts | Select-String -Pattern "getServerSession|next-auth|@clerk" | Select-Object -First 5 Path, Line
```

2. Trois cas possibles :
   - **`getServerSession` / `next-auth` apparait** → rien a faire, le defaut fonctionne. (Si `authOptions` est defini ailleurs que dans `@/lib/auth`, corrige juste le chemin de l'import ligne 22 de `nr-auth.ts`.)
   - **`@clerk` apparait** → ouvre `nr-auth.ts` et suis la **Variante C** (commentee en haut du fichier, 3 lignes a changer).
   - **Rien n'apparait** → cherche ou est definie ta session (`Get-ChildItem src -Recurse -Filter *.ts | Select-String "export const authOptions|export const { auth }"`) et suis la **Variante B** (NextAuth v5, commentee en haut du fichier).

### Etape 4 — Tester en local (1 min)

```powershell
npm run dev
```

Ouvre `http://localhost:3000/dashboard/lettres` (connecte-toi d'abord si besoin). En haut de la page, deux badges t'informent :
- vert « IA prete : groq · llama-3.3-70b... » → tout est bon ;
- orange « IA non detectee » → ton generateur de CV utilise une cle avec un autre nom : ajoute-la dans `.env` avec un des noms standards (`GROQ_API_KEY`, `OPENAI_API_KEY`, `MISTRAL_API_KEY`, `DEEPSEEK_API_KEY`, `GEMINI_API_KEY`, `ANTHROPIC_API_KEY`, `OPENROUTER_API_KEY`), ou utilise `AI_API_KEY` + `AI_BASE_URL` + `AI_MODEL` ;
- rouge « Base : lance npx prisma db push » → l'etape 2 n'a pas ete faite ou a echoue.

### Etape 5 — Lien dans la sidebar (1 min)

Ouvre ta sidebar (probablement `src/components/...` ou dans le layout du dashboard), copie un `<Link>` existant et adapte :

```tsx
<Link href="/dashboard/lettres">
  <FileText className="h-4 w-4" />
  <span>Lettres de motivation</span>
</Link>
```

(Ajoute `import { FileText } from "lucide-react"` si absent.)

### Etape 6 — Micro-fix du bug CV (2 min)

Voir section 4 ci-dessous.

### Etape 7 — Deployer (1 min)

```powershell
git add .
git commit -m "FEATURE : lettres de motivation IA + autosave"
git push origin main
```

Vercel redéploie automatiquement. **Aucune nouvelle variable d'environnement** n'est a ajouter sur Vercel si la cle IA existe deja.

---

## 3. Comment ca marche

1. **Nouvelle lettre** : tu renseignes poste, entreprise, ton, langue, et tu colles l'offre d'emploi et/ou le texte de ton CV (copie-le depuis le CV Builder).
2. **Generation IA** : la lettre complete (en-tete, objet, corps, formule de politesse) est generee puis **enregistree immediatement en base**.
3. **Edition** : chaque modification est sauvegardee automatiquement en base 1,2 s apres la frappe (indicateur « Enregistre a HH:MM » en haut a droite).
4. **Regle d'or (le reflexe qui manquait au CV Builder)** : avant Copier, Imprimer/PDF, Regenerer ou Retour a la liste, le contenu est **toujours sauvegarde en base d'abord** — l'export et la base sont donc toujours identiques.
5. **Export PDF** : bouton « Imprimer / PDF » → la fenetre d'impression du navigateur s'ouvre sur la lettre seule (sans le reste de l'interface) → choisis « Enregistrer au format PDF ».

## 4. Micro-fix : sauvegarde auto apres les ameliorations IA du CV

Ce script corrige la cause racine du bug « les boutons PDF/publication affichent un contenu vide ou different » : les ameliorations IA du CV n'etaient sauvegardees que dans la memoire du navigateur, pas en base.

Ce que fait le script :
1. Il **sauvegarde une copie de secours** de `createur/page.tsx` (`.bak-MICROFIX-<date>`).
2. Il detecte ta fonction de sauvegarde existante et ton gestionnaire d'amelioration IA.
3. Il branche une **sauvegarde automatique ~1,2 s apres chaque amelioration IA**, en utilisant ta fonction de sauvegarde existante (meme chemin que « Publier en ligne »).
4. **S'il n'est pas 100 % sur de ce qu'il trouve, il n'ecrit RIEN** et passe en « mode diagnostic » : il affiche les extraits concernes — copie-les dans la conversation et je te renvoie le fichier corrige complet.

Lancement (depuis la racine du projet, a cote de `package.json`) :

```powershell
powershell -ExecutionPolicy Bypass -File .\micro-fix-sauvegarde-ia.ps1
```

Apres application : teste une amelioration IA, attends 2 s, puis clique sur un des boutons PDF — le contenu doit desormais correspondre.

Annulation : copie le fichier `.bak-MICROFIX-...` sur `page.tsx`.

## 5. Depannage rapide

| Symptome | Solution |
|---|---|
| `Module not found: @/lib/auth` au build | Corrige le chemin de l'import dans `nr-auth.ts` (cherche `export const authOptions`) |
| `Module not found: next-auth` | Tu n'utilises pas NextAuth → variante B (Auth.js v5) ou C (Clerk) dans `nr-auth.ts` |
| `Module not found: @/components/ui/label` | `npx shadcn@latest add label` (idem pour `button`, `card`, `input`, `textarea` si besoin) |
| Erreur 502 « Aucune cle IA detectee » | Ajoute la cle IA dans `.env` (voir Etape 4) et redemarre `npm run dev` ; sur Vercel ajoute-la dans Settings > Environment Variables |
| Erreur 500 avec « CoverLetter inaccessible » | Lance `npx prisma db push` |
| Erreur 401 sur la page | Session non reconnue → Etape 3 (adaptation auth) |
| L'impression inclut la sidebar | Utilise Chrome ou Edge ; la page cache deja l'interface a l'impression |

## 6. Notes techniques

- `src/lib/ai-client.ts` fonctionne cote serveur uniquement ; la cle n'est jamais envoyee au navigateur (le badge n'affiche que le nom du provider et du modele).
- Le modele `CoverLetter` est volontairement **sans relation stricte** vers `User` pour eviter de toucher a ton schema existant (une variante avec relation est fournie en commentaire dans `AJOUTER-AU-SCHEMA.txt`).
- Compatibilite : Next.js 14/15/16 (params de route en `Promise` — fonctionne sur les deux generations).
